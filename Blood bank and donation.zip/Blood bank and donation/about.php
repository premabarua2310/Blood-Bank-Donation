<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- favicon -->
    <link rel="shortcut icon" href="images/favicon.png">
    <!-- font-awesome css-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
    <!-- main css -->
    <link rel="stylesheet" href="css/style.css">

    <title>Blood bank and donation</title>

</head>
<body>
    
    <!--header area starts-->
    <?php
    include "header.php";
    ?>
    <!--header area ends-->

    <!--about area starts-->
    <section id="about" class="about" >
        <div class="container" >
            <div class="about_img" >
                <img src="images/h.jpeg" width="105%" alt="">
            </div>
            <div class="about_heading" >
                <h4  class="head text-center" >about us</h4>
                <p>This is a non-profitable service motive Circle of Youths purely devoted for the welfare of society Encouraging and inspire people to donate blood and providing fresh blood to the needy people without any cost is the real goal of this organization. We feel one day no one of this country will die in scarcity of blood. People in need of blood contact us(in case they fail to manage from their family, friends, relatives or blood bank). In such condition, we manage blood donors from our database, which itself is the countries largest donor online database, we have more than 40 hundred donors registered. Since our registration, we successfully saved more than 30 hundred lives and have also brought smile at the faces of more than 35 hundred families throughout the country.</p>
            </div>
            <div class=" about_heading text-center" >
                <h4>blood donor camps</h4>
            </div>
            <div class="row" >

                    <div class="col-lg-4" >
                        <div class="about_img" >
                            <img src="images/1.jpg" class="w-100" alt="">
                        </div>
                        <div class="about_img" >
                            <img src="images/5.jpg" class="w-100" alt="">
                        </div>
                    </div>
                    <div class="col-lg-4" >
                        <div class="about_img" >
                            <img src="images/3.jpg" class="w-100" alt="">
                        </div>
                        <div class="about_img" >
                            <img src="images/4.jpg" class="w-100" alt="">
                        </div>
                    </div>
                    <div class="col-lg-4" >
                        <div class="about_img" >
                            <img src="images/5.jpg" class="w-100" alt="">
                        </div>
                        <div class="about_img" >
                            <img src="images/6.jpg" class="w-100" alt="">
                        </div>
                    </div>
                </div>
        </div>
    </section>
    <!--about area ends-->


    <!--footer area starts-->
    <?php
    include "footer.php";
    ?>
    <!--footer area ends-->


    <!-- jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
    

</body>
</html>