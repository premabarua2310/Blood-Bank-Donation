<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- favicon -->
    <link rel="shortcut icon" href="images/favicon.png">
    <!-- font-awesome css-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
    <!-- main css -->
    <link rel="stylesheet" href="css/style.css">

    <title>Blood bank and donation</title>

</head>
<body>
    
    <!--header area starts-->
    <?php
    include "header.php";
    ?>
    <!--header area ends-->

    <!--contact area starts-->
    <section id="contact" class="contact" >
        <div class="container">  
            <div class="contact_heading text-center" >
                <h4>get in touch</h4>
            </div>
            <div class="row" >
                <div class="col-lg-8" >
                <div class="contact_form" >
                    <form action="submitcon.php" method="POST" enctype="multipart/form-data">

                    <?php

                        if(isset($_COOKIE['error'])){
                            echo '<p style="color:green; font-weight:bold; font-size:20px;">'.$_COOKIE['error'].'</p><br>';
                            unset($_COOKIE['error']);
                        }
                
                    ?>

                    <div class="row">
                        <div class="col-25">
                            <label for="name">Full Name</label>
                        </div>
                        <div class="col-75">
                            <input type="text" id="name" name="name" placeholder="Enter your name..">
                        </div>
                    </div>
                <div class="row">
                    <div class="col-25">
                        <label for="phonenumber">Phone Number</label>
                    </div>
                    <div class="col-75">
                        <input type="number" id="phonenumber" name="phonenumber" placeholder="Enter phone number..">
                    </div>
                </div>
                <div class="row">
                    <div class="col-25">
                        <label for="email">Email</label>
                    </div>
                    <div class="col-75">
                        <input type="text" id="email" name="email" placeholder="Enter your email..">
                    </div>
                </div>
                <div class="row">
                    <div class="col-25">
                        <label for="message">Message</label>
                    </div>
                    <div class="col-75">
                        <textarea id="message" name="message" placeholder="Write something.." style="height:200px"></textarea>
                    </div>
                </div>
                <div class="row">
                    <input type="submit" value="Submit">
                </div>
                    </form>
                </div>
            </div>
            <div class="col-lg-4" >
                <div class="contact_img" >
                    <img src="images/contact img.jpg" width="90%" alt="">
                </div>
            </div>
            </div>
            <div class="contact_icon" >
                <ul>
                    <li>
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                    </li>
                    <li>
                        <a href="#"><i class="fab fa-google-plus-g"></i></a>
                    </li>
                    <li>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                    </li>
                    <li>
                        <a href="#"><i class="fab fa-linkedin-in"></i></a>
                    </li>
                </ul>
            </div>
        </div>
    </section>    
    <!--contact area ends-->

    <?php
        include "db.php";

        
    ?>

    <!--footer area starts-->
    <?php 
    include 'footer.php'; 
    ?>
    <!--footer area ends-->


    <!-- jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
    
</body>
</html>