<?php

    $conn = mysqli_connect("localhost", "root", "", "bloodbank");

    if($conn){
        //echo "Connection successfully";
    }
    else{
        echo "Connection unsuccessfull" .mysqli_connect_error();
    }
    

?>