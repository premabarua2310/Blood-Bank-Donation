<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- favicon -->
    <link rel="shortcut icon" href="images/favicon.png">
    <!-- font-awesome css-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
    <!-- main css -->
    <link rel="stylesheet" href="css/style.css">

    <title>Blood bank and donation</title>

</head>
<body>
    
    <!--header area starts-->
    <?php
    include "header.php";
    ?>
    <!--header area ends-->


    <!--banner area starts-->
    <section id="banner" class="banner">
        <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
                <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
                <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="images/a.png" class="d-block w-100" alt="...">
                    <div class="carousel-caption d-none d-md-block">
                    <h5>DONATE BLOOD SAVE LIFE</h5>
                    <p>Save a little, care a little, give blood.</p>
                </div>
                </div>
                <div class="carousel-item">
                    <img src="images/b.png" class="d-block w-100" alt="...">
                    <div class="carousel-caption d-none d-md-block">
                    <h5>EVERY BLOOD DONAR IS A LIFE SAVER.</h5>
                    <p>Donate blood today.</p>
                </div>
                </div>
                <div class="carousel-item">
                    <img src="images/c.jpg" class="d-block w-100" alt="...">
                    <div class="carousel-caption d-none d-md-block">
                    <h5>SOMEONE IS NEEDING BLOOD SOMEWHERE.</h5>
                    <p>Blood donation will cost you nothing but it will save a life.</p>
                </div>
                </div>
                
            </div>
            <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
    </section>
    <!--banner area ends-->

    <!--home area starts-->
    <section id="home" class="home" >
        <div class="container" >
            <div class="home_heading" >
                <h5>Welcome to blood bank and donation system</h5>
            </div>
            <div class="row" >
                <div class="col-lg-7" >
                    <div class="home_content" >
                        <p>A blood donation occurs when a person voluntarily has blood drawn and used for transfusions and/or made into biopharmaceutical medications by a process called fractionation (separation of whole-blood components). Donation may be of whole blood, or of specific components directly (the latter called apheresis). Blood banks often participate in the collection process as well as the procedures that follow it. Today in the developed world, most blood donors are unpaid volunteers who donate blood for a community supply.</p>
                    </div>
                </div>
                <div class="col-lg-5" >
                    <div class="home_img" >
                        <img src="images/homeimage.png" class="w-100" alt="">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--home area ends-->

    <!--home_service area starts-->
    <section id="home_service" class="home_service" >
        <div class="container" >
            <div class="row" >
                <div class="col-lg-4" >
                    <div class="home_ser_main" >
                        <div class="home_ser_icon" >
                        <img src="images/images.png" width="120%" alt="">
                        </div>
                        <div class="home_ser_content" >
                            <h4>the need for blood</h4>
                                <p>Lorem ipsum dolor sit amet, consectetpisg elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4" >
                    <div class="home_ser_main" >
                        <div class="home_ser_icon" >
                        <img src="images/images.png" width="120%" alt="">
                        </div>
                        <div class="home_ser_content" >
                            <h4>blood tips</h4>
                                <p>Lorem ipsum dolor sit amet, consectetpisg elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4" >
                    <div class="home_ser_main" >
                        <div class="home_ser_icon" >
                        <img src="images/images.png" width="120%" alt="">
                        </div>
                        <div class="home_ser_content" >
                            <h4>who you could help</h4>
                                <p>Lorem ipsum dolor sit amet, consectetpisg elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--home_service area ends-->

    <!--blood group area starts-->
    <section id="blood_group" class="blood_group">
            <div class="container" >
                <div class=" group_heading text-center" >
                    <h2>blood groups</h2>
                </div>
                    <div class="row" >
                        <div class="col-lg-5" >
                            <div class="group_img" >
                                <img src="images/g.png" class="w-60%" alt="">
                            </div>
                        </div>
                        <div class="col-lg-7" >
                            <div class="group_content" >
                                <p class="content1">Blood groups of any human being will mainly fall in any one of the following groups:</p>
                                <div class="grous_item" >
                                    <li>A positive or A negative</li>
                                    <li>B positive or B negative</li>
                                    <li>O positive or O negative</li>
                                    <li>AB positive or AB negative</li>
                                </div>
                                <p class="content2">A healthy diet helps ensure a successful blood donation and also makes you feel better.</p>
                            </div>
                        </div>
                    </div>
            </div>
        </section>
    <!--blood group area ends-->
    
    <!--footer area starts-->
    <?php
    include "footer.php";
    ?>
    <!--footer area ends-->


    <!-- jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>