<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- favicon -->
    <link rel="shortcut icon" href="images/favicon.png">
    <!-- font-awesome css-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
    <!-- main css -->
    <link rel="stylesheet" href="css/style.css">

    <title>Blood bank and donation</title>

</head>
<body>

    <!--header area starts-->
    <?php
    include "header.php";
    ?>
    <!--header area ends-->

    <!--login area starts-->
    <div class="container" >
    </div>
    <!--login area ends-->
    <section id="login" class="login">
        <div class="container" >
            <div class="login_heading text-center" >
                <h4>login form</h4>
            </div>
            <div class="login_form" >
                <form action="submitlog.php" method="POST">

                <?php

                if(isset($_COOKIE['error'])){
                    echo '<p style="color:green; font-size:20px; font-weight:bold;">'.$_COOKIE['error'].'</p><br>';
                    setcookie("error" , "" , time() - 60 );
                }
                
                ?>

                <div class="imgcontainer">
                    <img src="images/avatar.png" alt="Avatar" class="avatar">
                </div>
                <label for="username"><b>Username</b></label>
                <input type="text" placeholder="Enter Username" name="username" id="username" required>
                <label for="password"><b>Password</b></label>
                <input type="password" placeholder="Enter Password" name="password" id="password" required>
        
                <button type="submit">Login</button>
                <label>
                <input type="checkbox" checked="checked" name="remember"> Remember me</label>
            </div>
            <div class="container signin">
                <p><a href="registration.php">Create an account</a>.</p>
            </div>
                </form>
            </div>
        </div>
    </section>
    <!--footer area starts-->
    <?php 
    include 'footer.php'; 
    ?>
    <!--footer area ends-->


    <!-- jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
    
</body>
</html>