<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- favicon -->
    <link rel="shortcut icon" href="images/favicon.png">
    <!-- font-awesome css-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
    <!-- main css -->
    <link rel="stylesheet" href="css/style.css">

    <title>Blood bank and donation</title>

</head>
<body>

    <!--header area starts-->
    <?php
    include "header.php";
    ?>
    <!--header area ends-->

    <!--services area starts-->
    <section id="registration" class="registration" >
        <div class="container" >
            <div class="registration_heading text-center" >
                <h4>registration form</h4>
            </div>
            <div class="registration_form" >
            <form action="submitreg.php" method="POST">

            <!--php code starts-->
            <?php

                if(isset($_COOKIE['error'])){
                    echo '<p style="color:green; font-size:20px; font-weight:bold;">'.$_COOKIE['error'].'</p><br>';
                    setcookie("error" , "" , time() - 60 );
                }

            ?>
            <!--php code ends-->

            <div class="regform_heading" >
                <p>Please fill in this form to create an account.</p>
            </div>
                <label for="username"><b>Username</b></label>
                <input type="text" placeholder="Enter Username" name="username" id="username" required>
                <label for="email"><b>Email</b></label>
                <input type="text" placeholder="Enter Email" name="email" id="email" required>
                <label for="password"><b>Password</b></label>
                <input type="password" placeholder="Enter Password" name="password" id="password" required>
                <label for="phone"><b>Enter a phone number</b></label>
                <input type="tel" placeholder="Enter phone number" id="phone" name="phone" required>

                <button type="submit" name="submit" id="button" class="registerbtn">Register</button>
            </div>  
            <div class="container signin">
                <p>Already have an account? <a href="login.php">Sign in</a>.</p>
            </form>
            </div>
        </div>
    </section>
    <!--services area ends-->


    <!--footer area starts-->
    <?php 
    include 'footer.php'; 
    ?>
    <!--footer area ends-->


    <!-- jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
    
</body>
</html>