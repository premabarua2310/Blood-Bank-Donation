
    <?php

        $fullname = $_POST['name'];
        $phone = $_POST['phonenumber'];
        $email = $_POST['email'];
        $message = $_POST['message'];
        $conn = mysqli_connect("localhost", "root", "", "bloodbank");

        $query = "INSERT INTO contact VALUES ( '$fullname', $phone, '$email', '$message')";

        mysqli_query($conn, $query);
        
        setcookie("error", "Thanks For Your Responce", time() + 60);
        header('Location: contact.php');
        
    ?>

