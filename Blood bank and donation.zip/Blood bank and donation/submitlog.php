

    <?php

        $username = $_POST['username'];
        $password = $_POST['password'];
        $conn = mysqli_connect("localhost", "root", "", "bloodbank");

        $query = "INSERT INTO SUBMITLOG VALUES ('', '$username', '$password')";
        mysqli_query($conn, $query);
        
        setcookie("error", "Login successfully", time() + 60);
        header('Location: login.php');

    ?>    

